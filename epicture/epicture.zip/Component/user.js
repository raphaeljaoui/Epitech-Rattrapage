import React, { Component } from 'react';
import { StyleSheet, Text, View, Button, TextInput, Image, FlatList, SafeAreaView} from 'react-native';
import PhotoUser from './photoUser'
import Axios from 'axios'
import {connect} from 'react-redux'
const data = [
    {
        id:1,
        titre: "image1",
        description: "description", 
        image: "null"
    },
    {
        id:2,
        titre: "image1",
        description: "description", 
        image: "null"
    },
    {
        id:3,
        titre: "image1",
        description: "description", 
        image: "null"
    },
    {
        id:4,
        titre: "image1",
        description: "description", 
        image: "null"
    },
]

const IMGUR_CLIENT_ID = "b15555533adcf0c"

class User extends React.Component {
    constructor(props){
        super(props),
        this.state = {
            login: 0,
            username: "rj012",
            textUser: "",
            accountImgData: []
        }
    }

    _photoUser= async() => {   
        await Axios.get(`https://api.imgur.com/3/account/${this.props.currentProfil.data.url}/images`, {
            headers: { 
            'Authorization': `Client-ID ${IMGUR_CLIENT_ID}`, 
            },
            }).then((response) => {
                this.setState({accountImgData: response.data});
            console.log(response.data);
            }).catch((error) => {
                console.log(error);
            });
    }  

    componentDidMount = () => {
    this._photoUser()
    } 

    render(){
        // console.log(this.props.currentProfil.data);
        const profil = this.props.currentProfil.data
            return(
                <SafeAreaView style={styles.loginPage}>
                    <View style={{flexDirection: "row", alignItems:"center"}}>
                        <Image source={require('../image/imgur.jpeg')} style={{width:50, height: 50, borderRadius:40, marginLeft:20}} />
                        <Text style={{fontSize:18, color:"green", marginLeft:10}}>Imgur</Text>
                    </View>
                    <View style={{marginTop:30, alignItems: 'center',justifyContent: 'center'}}>
                        <Image source={{uri: profil.avatar}} style={{width:200, height:200,borderRadius:100}} />
                        <Text style={{fontSize:20, fontWeight:"600"}}>{profil.url}</Text>
                        <Text style={{fontSize:16}}>{profil.reputation_name}</Text>
                    </View>
                    <View style={{marginTop:50, alignItems: 'center',}}>
                        <FlatList 
                        data={data}
                        KeyExtractor={(item) => item.id.toString()}
                        renderItem={({item}) => <PhotoUser/>}
                        numColumns={3}
                        />
                    </View>
                </SafeAreaView>
            )
    }
}

const styles = StyleSheet.create({
  loginPage: {
    // alignItems: 'center',
    // justifyContent: 'center',
  },
});

const mapStateToProps = (store) => {
    return {
        currentProfil: store.profil.data
    }
}
export default connect(mapStateToProps, undefined)(User)