import React, { Component } from 'react';
import { StyleSheet, Text, View, Button, TextInput, Image, TouchableOpacity} from 'react-native';
import { WebView } from 'react-native-webview';
import Axios from 'axios'
import {connect} from 'react-redux'

const IMGUR_CLIENT_ID = "b15555533adcf0c"
class Login extends React.Component {
    constructor(props){
        super(props),
        this.state = {
            login: 0,
            username: "rj012",
            textUser: "",
            accountData: []
        }
    }

    _loginPage= async() => {   
        await Axios.get(`https://api.imgur.com/3/account/${this.state.textUser}`, {
            headers: { 
            'Authorization': `Client-ID ${IMGUR_CLIENT_ID}`, 
            },}).then((response) => {
                this.setState({accountData: response.data});
                this.props.nav(false)
                const action={type: "GET_PROFIL", value: response.data}
                this.props.dispatch(action)
            }).catch((error) => {
                console.log(error)
        });
    }

    render(){
        if (this.state.login ==0){
            return (
                <View style={{height: "80%", width:"100%", overflow:"hidden"}}>
                <WebView
                source = {{ uri: 'https://api.imgur.com/oauth2/authorize?client_id=b15555533adcf0c&response_type=token' }}      />
                    <Button title="login" onPress={() => { this.setState({login:1})}}/>
                </View>
            );
        }
        else if (this.state.login ==1){
            return(
                <View style={styles.loginPage}>
                    <Image source={require("../image/imgur.jpeg")} style={{width:80, height:80, marginTop:100, borderRadius:50}} />
                    <View style={{ marginTop:100, alignItems:"center"}}>
                    <Text style={{fontSize:18}}>Username</Text>
                    <TextInput 
                    style={{ height: 40, width:300, borderColor: 'gray', borderWidth: 1, borderRadius:50}}
                    onChangeText={user => this.setState({textUser: user})}
                    value={this.state.textUser}
                    placeholder ="Entrez votre username"
                    textAlign={'center'}
                    />
                    <TouchableOpacity onPress={() =>  {this._loginPage()}} style={{height:40, width:300, backgroundColor:"#5B6A12", borderRadius:50, marginTop:10, alignItems:"center", justifyContent:"center"}}>
                        <Text style={{color: "white"}}>Connection</Text>
                    </TouchableOpacity>
                    </View>
                </View>
            )
        }
    }
}

const styles = StyleSheet.create({
  loginPage: {
    backgroundColor: '#B1BB81',
    alignItems: 'center',
    height: "100%",
    width:"100%"
  },
});

const mapDispatchToProps = (dispatch) => {
    return {
      dispatch: (action) => { dispatch(action) }
    }
  }
export default connect(undefined, mapDispatchToProps)(Login)