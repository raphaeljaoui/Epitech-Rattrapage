import React, { Component } from 'react';
import { StyleSheet, Text, View, Button, TextInput, Image, FlatList, SafeAreaView} from 'react-native';
import PhotoUser from './photoUser'
const data = [
    {
        id:1,
        titre: "image1",
        description: "description", 
        image: "null"
    },
    {
        id:2,
        titre: "image1",
        description: "description", 
        image: "null"
    },
    {
        id:3,
        titre: "image1",
        description: "description", 
        image: "null"
    },
    {
        id:4,
        titre: "image1",
        description: "description", 
        image: "null"
    },
]

export default class Search extends React.Component {
    constructor(props){
        super(props),
        this.state = {
            search: ''
        }
    }  

    render(){
            return(
                <SafeAreaView style={styles.loginPage}>
                     <View style={{flexDirection: "row", alignItems:"center"}}>
                        <Image source={require('../image/imgur.jpeg')} style={{width:50, height: 50, borderRadius:40, marginLeft:20}} />
                        <Text style={{fontSize:18, color:"green", marginLeft:10}}>Imgur</Text>
                    </View>
                    <View style={{marginTop:30, alignItems: 'center',justifyContent: 'center'}}>
                        <TextInput 
                        style={{ height: 40, width:300, borderColor: 'gray', borderWidth: 1, borderRadius:20 }}
                        onChangeText={text => this.setState({search: text})}
                        value={this.state.search}
                        placeholder = " Recherche ..."
                        />
                    </View>
                    <View style={{marginTop:50, alignItems: 'center',}}>
                        <FlatList 
                        data={data}
                        KeyExtractor={(item) => item.id.toString()}
                        renderItem={({item}) => <PhotoUser/>}
                        numColumns={3}
                        />
                    </View>
                </SafeAreaView>
            )
    }
}

const styles = StyleSheet.create({
  loginPage: {
    // alignItems: 'center',
    // justifyContent: 'center',
  },
});
