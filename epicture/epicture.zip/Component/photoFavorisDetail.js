import React, { Component } from 'react';
import { StyleSheet, Text, View, Button, TextInput, Image, SafeAreaView} from 'react-native';

export default class PhotoDetailFavoris extends React.Component {
    render(){
        const fav = this.props.navigation.state.params.fav
        const widthX = fav.width / 10
        const heightX = fav.height / 10
            return(
                <SafeAreaView style={styles.loginPage}>
                    <View style={{ alignItems: 'center',justifyContent: 'center'}}>
                        <Image source={{uri: "https://i.imgur.com/" + fav.cover + ".jpg"}} style={{width:widthX, height:heightX,borderWidth:0.5, borderColor:"black", marginLeft:0.5}} />
                    </View>
                    <Text style={{marginTop:50}}>{fav.title}</Text>
                    <Text>Auteur: {fav.account_url}</Text>
                </SafeAreaView>
            )
    }
}

const styles = StyleSheet.create({
  loginPage: {
    alignItems: 'center',
    // justifyContent: 'center',
  },
});
