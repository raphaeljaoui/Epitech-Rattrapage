

function profil(state, action){
    return{
        profil: "raphael"
    }
}

export default profil